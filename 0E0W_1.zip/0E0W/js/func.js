function readFileToArr(inputAddress4) {
    var fReadName;
    switch(inputAddress4){
        case("宝钢股份"):
            fReadName = ".\\moban5708\\data\\baogangshares.txt";
            break;
        case("工商银行"):
            fReadName = ".\\moban5708\\data\\ICBC.txt";
            break;
        case("中国石油"):
            fReadName = ".\\moban5708\\data\\Chinaoil.txt";
            break;
        case("中国石化"):
            fReadName = ".\\moban5708\\data\\Chinashihua.txt";
            break;
        case("中国平安"):
            fReadName = ".\\moban5708\\data\\pingan.txt";
            break;
        case("中国铝业"):
            fReadName = ".\\moban5708\\data\\Al.txt";
            break;
    }
    var fso = new ActiveXObject("scripting.FileSystemObject");
    
    var f=fso.OpenTextFile(fReadName); //这里必须为绝对路径

    
    
    var arr = new Array(500);
    for (var i = 0; i < arr.length; i++) {
        arr[i]=new Array(15);
    }
    var j=0;
    while(!f.AtEndOfStream){
        var temp=f.ReadLine().split(); //读取一行数据并按空格分割
        for(i=0;i<temp.length;i++){
            console.log(temp[i]);
            arr[j][i]=temp[i];
        }
        j++;
    }
    return arr;
}


function func1(inputAddress1, inputAddress3,inputAddress4){//夏普比率
    var arr = readFileToArr(inputAddress4);
    alert(arr);
    var earning = (arr[0][0] - arr[0][3])*inputAddress1/arr[0][0];
    var yearEarning = (earning/inputAddress1)/inputAddress3;
    var standarddiviation = func2(inputAddress3, inputAddress4);

    sharpratio = (yearEarning - 0.015)/standarddiviation;
    alert(sharpratio);
}

function func2(inputAddress3,inputAddress4){
    var arr= readFileToArr(inputAddress4);
    var total= 0;
    var arr1 = [];
    for(var i =0; i<500;i++){
        if(arr[i][0] == NULL)break;
        var temp = arr[i][0] - arr[i][3];
        temp/=arr[i][3]*inputAddress3;
        arr1+=temp;
        total += temp;
    }
    var average = total/(i+1);
    var varance = 0;
    for(var j=0;j<i+1;j++){
        varance+= (arr1[j]-average)*(arr1[j]-average);
    }
    var standarddiviation = sqrt(varance);
    return standarddiviation;
}

function func3(inputAddress1){
    var exceedearning = inputAddress1/arr[0][3]*(arr[0][0] - a[0][3]) - inputAddress1*0.015;
    var expectedearning = func4() * inputAddress1/arr[0][3] * (1 - arr[0][0])/arr[0][0];
    var alpha = exceedearning - expectedearning;
    return alpha;
}
function func4(inputAddress1,inputAddress4){
        var arr = readFileToArr(inputAddress4);
        var arr1 = [];
        var total1 = 0;
        var arr2 = [];
        var total2 =0;
        for(var i=0; i<500;i++){
            if(arr[i][0] == "")break;
            var temp = (arr[i][0]-arr[i][3])*inputAddress1/arr[i][3];
            arr1.push(temp);
            total1 += temp;
            arr2.push(1-arr[i][0]);
            total2 +=1-arr[i][0];
        }
        var average1 = total1/(i+1);
        var average2 = total2/(i+1);
        var covariance = 0;
        var variance1 = 0;
        var variance2 = 0;
        var variance3 = 0;
        var variance4 = 0;
        for(var j=0; j<=i;j++){
            variance1 += arr1[i]*arr1[i];
            variance2 += arr2[i]*arr2[i];
            variance3 += (arr1[i]+arr2[i])*(arr1[i]+arr2[i]);
            variance4 += arr1[i]+arr2[i];
        }
        variance1 = variance1/(i+1) - average1*average1;
        variance2 = variance2/(i+1) - average2*average2;
        covariance = variance3/(i+1) - (variance4/(i+1))*(variance4/(i+1))-variance1-variance2;
        return covariance/variance2;
}

function func5(inputAddress1){
    var earning = inputAddress1 / arr[0][3] * (arr[0][0] - arr[0][3]);
    var huiCeEarning = earning / inputAddress1;
    return huiCeEarning;
}

function func6(inputAddress3){
    var earningratio = (arr[0][0] - arr[0][3]) / arr[0][3];
    var yearlyHuiCeEarning = Math.pow(1+earningratio, 243 / (inputAddress3*365)) -1;
    return yearlyHuiCeEarning;
}

function func7(inputAddress1,inputAddress3){
    var i1 = Math.max(0.015, arr[0][14]/(arr[0][12] + arr[0][13]));
    var rate = 0;
    switch(inputAddress3){
        case(1):rate = 2.025;
            break;
        case(2):rate = 2.815;
            break;
        case(3):rate = 3.66;
            break;
        case(4):
        case(5):rate = 3.515;
            break;
    }
    var futureValue = inputAddress1 * Math.pow(1+rate, inputAddress3);
    var i2 = Math.abs(futureValue - inputAddress1);
    var baseEarningsRatio = (i1+1) * (i2+1) * (0.67+1) - 1;
    return baseEarningsRatio;
}

function func8(inputAddress1,inputAddress3){
        annualYeild =func7(inputAddress1,inputAddress3);
        annualizedReturn = inputAddress1*annualYeild*inputAddress3;
        return annualizedReturn;
}

function func9(inputAddress4){
    switch(inputAddress4){
        case("宝钢股份"):
            return 8.57;
        case("工商银行"):
            return 7.67;
        case("中国石油"):
            return 6.84;
        case("中国石化"):
            return 6.16;
        case("中国平安"):
            return 43.32;
        case("中国铝业"):
            return 3.11;
    }
}

function func10(){
    var dayWinRate = 0;
    for(var i=0; i<243; i++){
        if(arr[i][0] >= arr[i][3])
            dayWinRate++;
    }
    return dayWinRate/243;
}

function func11(){
    var monthWinRate = 0;
    for(var i=0; i<243; i=i+20){
        if(arr[i][0] >= arr[i][3])
            monthWinRate++;
    }
    return monthWinRate/12;
}

function func12(){
    var arr = readFileToArr(inputAddress4);
    var earning = (arr[0][0] - arr[0][3])*inputAddress1/arr[0][0];
    var yearEarning = (earning/inputAddress1)/inputAddress3;

    var mean = 0;
    for(var k=0; k<500;k++){
        if(arr[k][0] == NULL)break;
        mean += arr[k][0];
    }
    mean /= k+1;
    var j = 0;
    for(var i=0; i<500; i++){
        if(arr[i+1][0] >= arr[i][0])
            i++;
        else{
            j += (arr[i][0] - mean) * (arr[i][0] - mean);
        }
        if(arr[i+1][0] == NULL)break;
    }
    var downStandarddiviation = sqrt(j / i);
    var Sortino = (yearEarning - 0.015) / downStandarddiviation;
    return Sortino;    
}

function func13(){
    var yearlyVolatility = func2(inputAddress3, inputAddress4) * pow(250, 0.5);
    return yearlyVolatility;
}

function func14(){
    
}

